n = ('hello python world')
print(n)