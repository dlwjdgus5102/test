n = int(input(5))
print(n)