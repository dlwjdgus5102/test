# 테스트 케이스마다 입력 값을 그대로 출력하세요.

T = int(input())

for t in range(1, T+1):
    print(t)