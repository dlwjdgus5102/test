# 과일 데이터 fruits.txt를 활용하여 이름이 berry로 끝나는 과일의 개수와 목록을 03.txt 에 기록하세요.

fruit_list = []
fruit_count = 0

with open('./data/fruits.txt', 'r') as f:
    fruits = f.readlines()
    for fruit in fruits:
        fruit = fruit.strip()
        if fruit[-5:] == 'berry':
            if fruit not in fruit_list:
                fruit_list.append(fruit)
                fruit_count += 1

with open('./03.txt', 'w') as f:
    # print(fruit_count)
    f.write(str(fruit_count) + '\n')

    for fruit in fruit_list:
        # print(fruit)
        f.write(fruit + '\n')