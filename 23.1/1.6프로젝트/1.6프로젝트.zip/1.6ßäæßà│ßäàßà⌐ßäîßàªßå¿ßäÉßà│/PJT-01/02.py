# 과일 데이터 fruits.txt를 활용하여 작성된 총 과일 개수를 02.txt 에 기록하세요.

count = 0

with open('./data/fruits.txt', 'r') as file:
    lines = file.readlines()
    for line in lines:
        count += 1

with open('./02.txt', 'w') as file:
    file.write(str(count))