import sys

sys.stdout = open('01.txt', 'w')

string = ('Hello, Python!', 
'1일차 파이썬 공부 중', 
'2일차 파이썬 공부 중', 
'3일차 파이썬 공부 중',
'4일차 파이썬 공부 중',
'5일차 파이썬 공부 중')

for element in string[::1]:
    print(element)
sys.stdout.close()