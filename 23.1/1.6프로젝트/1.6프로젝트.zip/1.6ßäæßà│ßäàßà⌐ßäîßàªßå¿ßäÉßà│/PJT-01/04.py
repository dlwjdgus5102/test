# 과일 데이터 fruits.txt를 활용하여 각 과일의 이름과 등장 횟수를 04.txt 에 기록하세요.

fruit_dict = {}

with open('./data/fruits.txt', 'r') as f:
    fruits = f.readlines()
    for fruit in fruits:
        fruit = fruit.strip()

        if fruit not in fruit_dict:
            fruit_dict[fruit] = 1

        elif fruit in fruit_dict:
            fruit_dict[fruit] += 1

with open('./04.txt', 'w') as f:
    for fruit, count in fruit_dict.items():
        # print(fruit, count)
        f.write(f'{fruit} {count} \n')
