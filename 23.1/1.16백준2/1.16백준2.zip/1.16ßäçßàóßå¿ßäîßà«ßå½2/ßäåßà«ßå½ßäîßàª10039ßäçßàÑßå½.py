a = max(40, int(input()))
b = max(40, int(input()))
c = max(40, int(input()))
d = max(40, int(input()))
e = max(40, int(input()))

print(int((a+b+c+d+e)/5))