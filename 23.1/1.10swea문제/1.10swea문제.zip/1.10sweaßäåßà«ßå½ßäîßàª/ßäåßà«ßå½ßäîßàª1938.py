a = int(input('1이상 자연수 입력> ')) 
b = int(input('9이하 자연수 입력> '))

n1 = (a+b)
n2 = (a-b)
n3 = (a*b)
n4 = int(a/b)
print(n1, n2, n3, n4)