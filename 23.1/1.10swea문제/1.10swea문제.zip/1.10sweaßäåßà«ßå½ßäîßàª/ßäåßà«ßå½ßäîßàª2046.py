n = int(input('100000이하 숫자 입력'))
print('#'*n)