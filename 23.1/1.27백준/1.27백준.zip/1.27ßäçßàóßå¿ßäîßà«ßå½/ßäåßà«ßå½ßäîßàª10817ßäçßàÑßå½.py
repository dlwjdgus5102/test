a = map(int, input().split())
b = sorted(a)
print(b[1])