str = input().split()

print(str)