T = int(input())

for t in range(1, T+1):
    N = int(input())

    for _ in range(N):
       
        a, b = list(map(int,input().split()))
        print(a, b)