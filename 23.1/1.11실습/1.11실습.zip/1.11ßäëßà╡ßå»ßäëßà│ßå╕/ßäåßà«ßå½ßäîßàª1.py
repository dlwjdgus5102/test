numbers = list(map(int,input().split()))

print(numbers)