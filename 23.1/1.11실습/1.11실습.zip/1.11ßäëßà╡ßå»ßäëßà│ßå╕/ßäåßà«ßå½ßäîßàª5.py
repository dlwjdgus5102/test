T = int(input())

for t in range(1, T+1):
    N = int(input())

    for _ in range(N):
       
        str = input().split()
        print(str)