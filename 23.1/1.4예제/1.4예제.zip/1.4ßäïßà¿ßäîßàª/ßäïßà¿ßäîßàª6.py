i = 0
while i <= 10:
    i = i + 2
    print(i)
# 2 4 6 8 10 12