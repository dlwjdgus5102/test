list_variable = [0, 1, 2, 3, 4, 5, 6]
print(sum(list_variable)) # 21