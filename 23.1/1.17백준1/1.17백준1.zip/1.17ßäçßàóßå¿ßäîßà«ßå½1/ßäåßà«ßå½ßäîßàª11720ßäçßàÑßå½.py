a = int(input())
n = list(input())
sum = 0
for i in n:
    sum += int(i)
print(sum)