T = int(input())
for i in range(T):
    N = int(input())
    print(sum(list(map(int,input().split()))))