a, b, c, d = input().split()
n1 = a+b
n2 = c+d

n1 = int(n1)
n2 = int(n2)

print(n1+n2)