number1 = input('첫 번째 문장을 입력해주세요 >')
number2 = input('두 번째 문장을 입력해주세요 >')
print(number1, number2)