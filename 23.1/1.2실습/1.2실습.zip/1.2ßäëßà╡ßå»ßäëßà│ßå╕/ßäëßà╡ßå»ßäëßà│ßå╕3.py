number1 = input('이름을 입력해주세요 > ')
number2 = 2024 - int(input('태어난 년도를 입력해주세요 > '))
print(number1, number2)