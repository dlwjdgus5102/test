number1 = input('문자열을 입력해주세요 >')
number2 = int(input('정수형 숫자를 입력해주세요 >'))
print(number1 * number2)