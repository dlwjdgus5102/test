number = input('좋아하는 음식을 입력해주세요')
print(number)