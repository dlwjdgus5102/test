#정수 한 개를 입력 받고, 해당 정수의 절대값을 출력하세요.
#단, abs() 함수는 사용하지 마세요.

n = int(input('정수를 입력하세요 >'))

if n>=0:
    print(n)
elif n<-1:
    print(0-n)