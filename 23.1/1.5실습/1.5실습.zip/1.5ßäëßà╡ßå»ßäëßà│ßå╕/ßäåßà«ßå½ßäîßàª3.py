# 입력과 같은 딕셔너리 변수가 있을 때, 해당 인물의 나이를 출력하세요.
n = int(input('출생년을 입력해주세요 >'))

dict_variable = {
    "이름": "정우영",
    "생년": "20000101",
    "회사": "하이퍼그로스",
}

dict_variable['나이'] = 2024-n

print(dict_variable)