# 문자열을 입력 받고 문자열에서 e 의 개수를 구해서 출력하세요.
# 단, count() 함수는 사용하지마세요.

string = input("문자열을 입력하세요 > ")
count = 0
for char in string:
    if char == "e":
        count += 1

print(count)