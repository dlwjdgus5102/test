# 정수 한 개를 입력 받고, 해당 정수가 1 보다 크고, 10보다 작다면 True 아니면 False를 출력하세요.

n = int(input('정수를 입력하세요 >'))

if 1<n<10:
    print(True)
else:
    print(False)