# 구구단을 출력하세요.

for i in range(2, 10):
    for k in range(1, 10):
     print(i, '*', k, '=', i*k)