# 정수 한 개를 입력 받고, 해당 숫자가 0보다 큰 숫자라면 True 아니면 False를 출력하세요.

n = int(input('정수를 입력하세요 > '))

if n > 1:
    print(True)
else:
    print(False)