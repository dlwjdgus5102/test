# 문자열을 입력 받고, 입력 받은 문자열을 반대로 한 글자씩 출력하세요.

n = input('문자열을 입력하세요 >')

for idx in range(len(n)):
    print(n[idx])

# 반대로 하는법 찾기