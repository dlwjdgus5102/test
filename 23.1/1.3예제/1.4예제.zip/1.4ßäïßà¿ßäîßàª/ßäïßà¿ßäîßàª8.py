n = 10

for element in range(1, n + 1, 3):
    print(element, end=" ")
# 1 4 7 10