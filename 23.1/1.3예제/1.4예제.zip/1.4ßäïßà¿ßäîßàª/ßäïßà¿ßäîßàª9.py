list_variable = [6, 5, 4, 3, 2, 1, 0] 

# enumerate가 무엇인지 검색해보세요!
for index, element in enumerate(list_variable):
    print(index, element)
# 0 6
# 1 5
# 2 4
# 3 3
# 4 2
# 5 1
# 6 0