string = "hello world!"

for element in string:
    print(element)
# h
# e
# l
# l
# o

# w
# o
# r
# l
# d