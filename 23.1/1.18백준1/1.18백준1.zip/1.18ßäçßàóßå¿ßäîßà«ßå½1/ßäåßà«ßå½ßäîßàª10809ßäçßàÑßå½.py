t = input()
a = 'abcdefghijklmnopqrstuvwxyz'
for i in a:
    print(t.find(i),end = ' ')