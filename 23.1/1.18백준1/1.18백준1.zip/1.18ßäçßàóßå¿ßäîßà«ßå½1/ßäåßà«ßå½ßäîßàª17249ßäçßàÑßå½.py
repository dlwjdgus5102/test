a,b = input().split("(^0^)")
a1 = a.count('@')
b1 = b.count('@')
print(a1,b1)