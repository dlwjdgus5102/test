name = input('이정현')

print(name) # '너의 이름은?'