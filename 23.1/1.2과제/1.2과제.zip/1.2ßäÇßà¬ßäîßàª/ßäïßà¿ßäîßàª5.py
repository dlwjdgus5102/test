string = 'abc hello def'
sub_string1 = string[4:10]
sub_string2 = string[1:4]
sub_string3 = string[-1]

print(sub_string1) # hello
print(sub_string2) # bc
print(sub_string3) # f