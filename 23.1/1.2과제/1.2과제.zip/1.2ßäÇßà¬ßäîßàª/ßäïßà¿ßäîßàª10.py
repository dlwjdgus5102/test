age = int(input('올해 나이'))

print('올해 나이 : ', age) # 올해 나이 28
print('내년 나이 : ', age + 1) # 내년 나이 29