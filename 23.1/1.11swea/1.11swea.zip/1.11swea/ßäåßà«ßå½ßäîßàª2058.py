n = input()
n1 = list(n)
n2 = list(map(int,n1))
print(sum(n2))