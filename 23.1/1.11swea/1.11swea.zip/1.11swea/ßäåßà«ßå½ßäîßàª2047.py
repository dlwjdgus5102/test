n = input()
print(n.upper())