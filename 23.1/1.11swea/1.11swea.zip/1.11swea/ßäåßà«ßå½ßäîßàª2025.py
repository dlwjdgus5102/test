n = int(input())
n1 = list(range(1, n+1))
print(sum(n1))